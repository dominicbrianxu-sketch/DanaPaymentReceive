package com.varino.danapaymentreceiver

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private lateinit var endpointInput: TextInputEditText
    private lateinit var tokenInput: TextInputEditText
    private lateinit var statusText: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        endpointInput = findViewById(R.id.urlInput)
        tokenInput = findViewById(R.id.tokenInput)
        statusText = findViewById(R.id.statusText)

        endpointInput.setText(Prefs.getEndpoint(this))
        tokenInput.setText(Prefs.getToken(this))

        findViewById<MaterialButton>(R.id.saveButton).setOnClickListener {
            val endpoint = endpointInput.text?.toString()?.trim().orEmpty()
            val token = tokenInput.text?.toString()?.trim().orEmpty()
            if (endpoint.isBlank() || token.isBlank()) {
                Toast.makeText(this, "Endpoint dan token wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.save(this, endpoint, token)
            startHeartbeat()
            updateStatus()
            Toast.makeText(this, "Konfigurasi disimpan", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.permissionButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<MaterialButton>(R.id.testButton).setOnClickListener {
            Prefs.save(
                this,
                endpointInput.text?.toString()?.trim().orEmpty(),
                tokenInput.text?.toString()?.trim().orEmpty()
            )
            PaymentSender.sendTest(this) { ok, message ->
                runOnUiThread {
                    statusText.text = if (ok) {
                        "DANA Notification: ${if (DanaNotificationListener.isEnabled(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\nPayment Server: 🟢 CONNECTED\n$message"
                    } else {
                        "DANA Notification: ${if (DanaNotificationListener.isEnabled(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\nPayment Server: 🔴 DISCONNECTED\n$message"
                    }
                }
            }
        }

        startHeartbeat()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun startHeartbeat() {
        val intent = Intent(this, ReceiverHeartbeatService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun updateStatus() {
        statusText.text =
            "DANA Notification: ${if (DanaNotificationListener.isEnabled(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\n" +
            "Payment Server: ${if (Prefs.serverOk(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\n" +
            Prefs.serverMsg(this)
    }
}
