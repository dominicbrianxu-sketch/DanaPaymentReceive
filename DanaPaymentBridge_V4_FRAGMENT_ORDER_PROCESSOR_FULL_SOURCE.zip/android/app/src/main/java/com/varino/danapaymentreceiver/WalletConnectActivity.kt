package com.varino.danapaymentreceiver

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WalletConnectActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallet_connect)

        webView = findViewById(R.id.walletWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.addJavascriptInterface(WalletBridge(), "AndroidWallet")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleExternalUrl(request.url.toString())
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleExternalUrl(url)
            }
        }

        val manifest = Prefs.getTonConnectManifest(this)
        if (manifest.isBlank()) {
            Toast.makeText(
                this,
                "Manifest TON Connect belum diisi. Isi URL HTTPS manifest di menu utama.",
                Toast.LENGTH_LONG
            ).show()
        }

        webView.loadUrl("file:///android_asset/wallet_connect.html?manifest=" + Uri.encode(manifest))
    }

    private fun handleExternalUrl(url: String): Boolean {
        val lower = url.lowercase()
        val walletLink = lower.startsWith("tonkeeper-tc://") ||
            lower.startsWith("bitkeep://") ||
            lower.startsWith("tc://") ||
            lower.startsWith("https://app.tonkeeper.com/ton-connect") ||
            lower.startsWith("https://bkcode.vip/ton-connect")

        if (!walletLink) return false

        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Aplikasi wallet tidak dapat dibuka: ${e.message}", Toast.LENGTH_LONG).show()
            true
        }
    }

    inner class WalletBridge {
        @JavascriptInterface
        fun connected(appName: String, address: String) {
            runOnUiThread {
                Prefs.saveWalletConnection(this@WalletConnectActivity, appName, address)
                Toast.makeText(
                    this@WalletConnectActivity,
                    "✅ $appName terhubung\n$address",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        @JavascriptInterface
        fun disconnected() {
            runOnUiThread {
                Prefs.clearWalletConnection(this@WalletConnectActivity)
                Toast.makeText(this@WalletConnectActivity, "Wallet terputus", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun error(message: String) {
            runOnUiThread {
                Toast.makeText(this@WalletConnectActivity, "TON Connect: $message", Toast.LENGTH_LONG).show()
            }
        }
    }
}
