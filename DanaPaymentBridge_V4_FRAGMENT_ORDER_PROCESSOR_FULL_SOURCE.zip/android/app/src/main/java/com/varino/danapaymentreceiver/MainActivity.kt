package com.varino.danapaymentreceiver

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private lateinit var endpointInput: TextInputEditText
    private lateinit var tokenInput: TextInputEditText
    private lateinit var manifestInput: TextInputEditText
    private lateinit var statusText: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        endpointInput = findViewById(R.id.urlInput)
        tokenInput = findViewById(R.id.tokenInput)
        manifestInput = findViewById(R.id.manifestInput)
        statusText = findViewById(R.id.statusText)

        endpointInput.setText(Prefs.getEndpoint(this))
        tokenInput.setText(Prefs.getToken(this))
        val savedManifest = Prefs.getTonConnectManifest(this)
        manifestInput.setText(savedManifest.ifBlank { deriveManifestUrl(Prefs.getEndpoint(this)) })

        findViewById<MaterialButton>(R.id.saveButton).setOnClickListener {
            val endpoint = endpointInput.text?.toString()?.trim().orEmpty()
            val token = tokenInput.text?.toString()?.trim().orEmpty()
            val manifest = manifestInput.text?.toString()?.trim().orEmpty()
            if (endpoint.isBlank() || token.isBlank()) {
                Toast.makeText(this, "Endpoint dan token wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.save(this, endpoint, token)
            if (manifest.isNotBlank()) Prefs.saveTonConnectManifest(this, manifest)
            startHeartbeat()
            updateStatus()
            Toast.makeText(this, "Konfigurasi disimpan", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.permissionButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<MaterialButton>(R.id.batteryButton).setOnClickListener {
            requestIgnoreBatteryOptimizations()
        }

        findViewById<MaterialButton>(R.id.tonkeeperTestButton).setOnClickListener {
            openTonkeeperForTest()
        }

        findViewById<MaterialButton>(R.id.exchangeWalletTestButton).setOnClickListener {
            openExchangeWalletForTest()
        }

        findViewById<MaterialButton>(R.id.walletConnectButton).setOnClickListener {
            val manifest = manifestInput.text?.toString()?.trim().orEmpty()
            if (manifest.isBlank()) {
                Toast.makeText(this, "Isi URL HTTPS TON Connect manifest terlebih dahulu", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            Prefs.saveTonConnectManifest(this, manifest)
            startActivity(Intent(this, WalletConnectActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.testButton).setOnClickListener {
            Prefs.save(
                this,
                endpointInput.text?.toString()?.trim().orEmpty(),
                tokenInput.text?.toString()?.trim().orEmpty()
            )
            PaymentSender.sendTest(this) { ok, message ->
                runOnUiThread {
                    statusText.text = if (ok) {
                        "DANA Notification: ${if (DanaNotificationListener.isEnabled(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\nPayment Server: 🟢 CONNECTED\n$message"
                    } else {
                        "DANA Notification: ${if (DanaNotificationListener.isEnabled(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\nPayment Server: 🔴 DISCONNECTED\n$message"
                    }
                }
            }
        }

        startHeartbeat()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun deriveManifestUrl(endpoint: String): String {
        return try {
            val uri = Uri.parse(endpoint)
            if (!uri.scheme.isNullOrBlank() && !uri.host.isNullOrBlank()) {
                "${uri.scheme}://${uri.host}${if (uri.port > 0) ":${uri.port}" else ""}/tonconnect-manifest.json"
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun startHeartbeat() {
        val intent = Intent(this, ReceiverHeartbeatService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        if (isIgnoringBatteryOptimizations()) {
            Toast.makeText(this, "Optimasi baterai untuk app ini sudah nonaktif", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Sebagian OEM (custom ROM) tidak mendukung dialog ini -> arahkan ke halaman
            // pengaturan baterai umum supaya user tetap bisa atur manual.
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "Buka manual: Pengaturan > Baterai > pilih app ini > Tidak dibatasi", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openTonkeeperForTest() {
        // TON Connect's documented Tonkeeper deep link. This test only opens the
        // wallet/connection entry point; it does NOT create or sign a transaction.
        val candidates = listOf(
            Intent(Intent.ACTION_VIEW, Uri.parse("tonkeeper-tc://")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://app.tonkeeper.com/ton-connect"))
        )
        launchFirstAvailable(candidates, "Tonkeeper")
    }

    private fun openExchangeWalletForTest() {
        // Bitget Wallet (formerly BitKeep) Android package is com.bitkeep.wallet.
        // The fallback deep link is only an app-open test; no transfer parameters
        // are supplied, so this does not initiate a payment/withdrawal.
        val candidates = listOf(
            Intent().apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_LAUNCHER)
                setPackage("com.bitkeep.wallet")
            },
            Intent(Intent.ACTION_VIEW, Uri.parse("bitkeep://"))
        )
        launchFirstAvailable(candidates, "Bitget Wallet")
    }

    private fun launchFirstAvailable(candidates: List<Intent>, walletName: String) {
        for (intent in candidates) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    Toast.makeText(this, "Membuka $walletName...", Toast.LENGTH_SHORT).show()
                    return
                }
            } catch (_: Exception) {
                // Try the next supported launch method.
            }
        }
        Toast.makeText(
            this,
            "$walletName belum terpasang atau tidak menyediakan deep link yang didukung",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun updateStatus() {
        val batteryLine = if (isIgnoringBatteryOptimizations()) {
            "Optimasi Baterai: 🟢 SUDAH DINONAKTIFKAN"
        } else {
            "Optimasi Baterai: 🔴 MASIH AKTIF (bisa memutus koneksi di background)"
        }
        statusText.text =
            "DANA Notification: ${if (DanaNotificationListener.isEnabled(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\n" +
            "Payment Server: ${if (Prefs.serverOk(this)) "🟢 CONNECTED" else "🔴 DISCONNECTED"}\n" +
            "$batteryLine\n" +
            Prefs.serverMsg(this)
    }
}
