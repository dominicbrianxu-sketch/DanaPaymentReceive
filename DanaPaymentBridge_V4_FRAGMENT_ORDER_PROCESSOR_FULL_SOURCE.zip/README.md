# DANA Payment Receiver V2 + Telegram Payment Bridge

- `android/`: APK Notification Listener DANA + heartbeat.
- `server/`: payment matching server + Telegram bot adapter.
- `codemagic.yaml`: build APK.

Flow:
Telegram `/order` -> server buat expected_amount (base + kode unik 3 digit) ->
bot kirim QRIS + nominal wajib -> notifikasi DANA masuk di HP -> APK kirim ke
server -> server cocokkan nominal PERSIS -> status jadi PAID -> **server langsung
kirim notif ke buyer di Telegram (otomatis, tanpa perlu cek manual)**.

## Fitur notifikasi koneksi (baru)
Server memantau heartbeat APK (`dana_receiver`) dan bot (`telegram_bot`) tiap 20
detik. Kalau salah satunya berubah status TERHUBUNG <-> TERPUTUS, dan
`ADMIN_CHAT_ID` diisi di `.env`, server otomatis kirim pesan ke chat itu. Lihat
`server/.env.example` untuk cara mendapatkan `ADMIN_CHAT_ID`.

Do not commit tokens. Use HTTPS in production.


## TON Connect Wallets (V3)

APK V3 sekarang memiliki koneksi TON Connect nyata untuk dua wallet yang diminta:
- Tonkeeper (`tonkeeper`)
- Bitget Wallet (`bitgetTonWallet`)

Koneksi memakai TON Connect, bukan seed/private key. Wallet menampilkan permintaan koneksi dan user menyetujui dari wallet. TON Connect menggunakan manifest HTTPS publik; wallet mengambil `tonconnect-manifest.json` sebelum koneksi.

### Server
Set `TONCONNECT_PUBLIC_BASE_URL` ke URL HTTPS publik server, tanpa slash di akhir. Server menyediakan:
- `/tonconnect-manifest.json`
- `/tonconnect-icon.png`

Contoh:
`https://domain-anda.example.com/tonconnect-manifest.json`

### APK
Isi `TON Connect manifest URL (HTTPS)` dengan URL tersebut, lalu tekan `Hubungkan Tonkeeper / Bitget Wallet`. Setelah user menyetujui, APK menyimpan wallet app name dan address secara lokal.

Tombol test lama tetap tersedia dan hanya membuka aplikasi wallet; tombol Hubungkan menggunakan TON Connect.
