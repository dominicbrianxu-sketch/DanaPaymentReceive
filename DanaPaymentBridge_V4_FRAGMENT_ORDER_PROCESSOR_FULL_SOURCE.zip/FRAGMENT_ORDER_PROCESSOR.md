# Fragment Order Processor — Additive Integration

This layer is intentionally additive. Existing DANA/payment, TON Connect,
Tonkeeper, Bitget Wallet, notification, receiver, heartbeat, and build files
must remain unchanged.

## Intended flow

DANA payment confirmed
    -> existing order is marked paid by the existing payment flow
    -> Stars order is queued for Fragment processing
    -> Android worker receives the queued order
    -> Fragment page is opened with the order context
    -> connected TON wallet can be used through TON Connect
    -> wallet authorization/signing is performed by the wallet
    -> order is marked completed only after a verifiable successful result

## Security

No seed phrase or private key is stored or transmitted by this layer.

## Important

There is no invented Fragment HTTP endpoint here. Fragment purchase/Stars
execution must use an actually supported Fragment flow. TON Connect can
request wallet transactions, but wallet authorization/signing remains in the
wallet.

## Wallet test functions

The existing V3 test functions remain:
- Test Buka Tonkeeper
- Test Buka Wallet Exchange / Bitget Wallet
- Connect Tonkeeper
- Connect Bitget Wallet
