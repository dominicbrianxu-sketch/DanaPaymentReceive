import os, sqlite3, uuid, hashlib
from datetime import datetime, timedelta, timezone
from contextlib import closing
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
DB=os.getenv('PAYMENT_DB','payments.db'); TOKEN=os.getenv('PAYMENT_TOKEN','CHANGE_ME'); WIB=timezone(timedelta(hours=7))
app=FastAPI(title='DANA Payment Bridge',version='2.0')
class OrderIn(BaseModel):
 telegram_user_id:str; product:str=''; base_amount:int=Field(gt=0); unique_code:int=Field(ge=1,le=999); expires_minutes:int=Field(default=15,ge=1,le=120)
class Heartbeat(BaseModel):
 device:str='unknown'; app_version:str='unknown'; notification_access:bool=False; source:str='DANA'
class PaymentIn(BaseModel):
 nominal:int=Field(gt=0); nama_pengirim:str=''; waktu:str=''; jenis_transaksi:str='QRIS'; catatan:str=''; source:str='DANA'; fingerprint_hint:str=''
def db(): c=sqlite3.connect(DB,timeout=20); c.row_factory=sqlite3.Row; return c
def now(): return datetime.now(WIB)
def iso(dt): return dt.isoformat()
def auth(t):
 if not t or t!=TOKEN: raise HTTPException(401,'invalid token')
def init():
 with closing(db()) as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS orders(order_id TEXT PRIMARY KEY,telegram_user_id TEXT NOT NULL,product TEXT,base_amount INTEGER NOT NULL,unique_code INTEGER NOT NULL,expected_amount INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,paid_at TEXT,payment_ref TEXT UNIQUE); CREATE INDEX IF NOT EXISTS idx_orders_match ON orders(expected_amount,status,expires_at); CREATE TABLE IF NOT EXISTS heartbeats(name TEXT PRIMARY KEY,last_seen TEXT NOT NULL,meta TEXT);'''); c.commit()
init()
@app.get('/health')
def health():
 t=now()
 with closing(db()) as c: rows=c.execute('SELECT name,last_seen,meta FROM heartbeats').fetchall()
 out={r['name']:{'last_seen':r['last_seen'],'meta':r['meta']} for r in rows}
 for v in out.values():
  try: v['online']=(t-datetime.fromisoformat(v['last_seen'])).total_seconds()<90
  except: v['online']=False
 return {'ok':True,'time':iso(t),'components':out}
@app.post('/receiver-heartbeat')
def receiver_hb(data:Heartbeat,x_tasker_token:str=Header(default='')):
 auth(x_tasker_token)
 with closing(db()) as c: c.execute("INSERT INTO heartbeats(name,last_seen,meta) VALUES('dana_receiver',?,?) ON CONFLICT(name) DO UPDATE SET last_seen=excluded.last_seen,meta=excluded.meta",(iso(now()),str(data.model_dump()))); c.commit()
 return {'ok':True,'component':'dana_receiver'}
@app.post('/bot-heartbeat')
def bot_hb(x_tasker_token:str=Header(default='')):
 auth(x_tasker_token)
 with closing(db()) as c: c.execute("INSERT INTO heartbeats(name,last_seen,meta) VALUES('telegram_bot',?,?) ON CONFLICT(name) DO UPDATE SET last_seen=excluded.last_seen",(iso(now()),)); c.commit()
 return {'ok':True,'component':'telegram_bot'}
@app.post('/receiver-test')
def receiver_test(data:Heartbeat,x_tasker_token:str=Header(default='')):
 auth(x_tasker_token); return {'ok':True,'message':'DANA receiver connected'}
@app.post('/orders')
def create_order(data:OrderIn,x_tasker_token:str=Header(default='')):
 auth(x_tasker_token); expected=data.base_amount+data.unique_code; t=now(); exp=t+timedelta(minutes=data.expires_minutes); oid='ORD-'+t.strftime('%Y%m%d%H%M%S')+'-'+uuid.uuid4().hex[:6].upper()
 with closing(db()) as c:
  existing=c.execute("SELECT order_id FROM orders WHERE expected_amount=? AND status='PENDING' AND expires_at>?",(expected,iso(t))).fetchone()
  if existing: raise HTTPException(409,'nominal sedang dipakai order lain')
  c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?)',(oid,data.telegram_user_id,data.product,data.base_amount,data.unique_code,expected,'PENDING',iso(t),iso(exp),None,None)); c.commit()
 return {'ok':True,'order_id':oid,'expected_amount':expected,'status':'PENDING','expires_at':iso(exp)}
@app.get('/orders/{order_id}')
def order_status(order_id:str,x_tasker_token:str=Header(default='')):
 auth(x_tasker_token)
 with closing(db()) as c: r=c.execute('SELECT * FROM orders WHERE order_id=?',(order_id,)).fetchone()
 if not r: raise HTTPException(404,'order not found')
 if r['status']=='PENDING' and datetime.fromisoformat(r['expires_at'])<=now():
  with closing(db()) as c: c.execute("UPDATE orders SET status='EXPIRED' WHERE order_id=? AND status='PENDING'",(order_id,)); c.commit()
  return {**dict(r),'status':'EXPIRED'}
 return dict(r)
@app.post('/payment-notify')
def payment_notify(data:PaymentIn,x_tasker_token:str=Header(default='')):
 auth(x_tasker_token); t=now()
 with closing(db()) as c:
  c.execute("UPDATE orders SET status='EXPIRED' WHERE status='PENDING' AND expires_at<=?",(iso(t),))
  r=c.execute("SELECT * FROM orders WHERE expected_amount=? AND status='PENDING' AND expires_at>? ORDER BY created_at LIMIT 1",(data.nominal,iso(t))).fetchone()
  if not r: c.commit(); return {'ok':True,'matched':False,'nominal':data.nominal,'message':'no pending order with exact nominal'}
  ref=hashlib.sha256(f"{r['order_id']}|{data.nominal}|{data.waktu}|{data.catatan}".encode()).hexdigest()
  c.execute("UPDATE orders SET status='PAID',paid_at=?,payment_ref=? WHERE order_id=? AND status='PENDING'",(iso(t),ref,r['order_id'])); c.commit()
 return {'ok':True,'matched':True,'order_id':r['order_id'],'telegram_user_id':r['telegram_user_id'],'expected_amount':r['expected_amount'],'status':'PAID','payment_ref':ref}
