import os, asyncio, httpx
from telegram import Update
from telegram.ext import Application,CommandHandler,ContextTypes
BOT_TOKEN=os.environ['TELEGRAM_BOT_TOKEN']; API=os.getenv('PAYMENT_API','http://127.0.0.1:5005'); PAYMENT_TOKEN=os.environ['PAYMENT_TOKEN']; QRIS_FILE=os.getenv('QRIS_FILE','qris.png')
async def api(method,path,data=None):
 async with httpx.AsyncClient(timeout=15) as c:
  r=await c.request(method,API+path,headers={'X-Tasker-Token':PAYMENT_TOKEN},json=data); r.raise_for_status(); return r.json()
async def start(u,c): await u.message.reply_text('Payment bridge aktif. Contoh: /order 12000 ProdukA')
async def order(u,c):
 if not c.args: return await u.message.reply_text('Format: /order 12000 NamaProduk')
 base=int(c.args[0]); product=' '.join(c.args[1:]) or 'Produk'; data=None
 for code in range(123,1000):
  try: data=await api('POST','/orders',{'telegram_user_id':str(u.effective_user.id),'product':product,'base_amount':base,'unique_code':code,'expires_minutes':15}); break
  except httpx.HTTPStatusError as e:
   if e.response.status_code!=409: raise
 if not data: return await u.message.reply_text('Tidak ada nominal unik yang tersedia.')
 await u.message.reply_text(f"🧾 Order: {data['order_id']}\n💰 Total QRIS: Rp{data['expected_amount']:,}\n⏳ Berlaku sampai: {data['expires_at']}\n\nBayar PERSIS sesuai nominal. Setelah DANA terdeteksi, order otomatis divalidasi.")
 try:
  with open(QRIS_FILE,'rb') as f: await u.message.reply_photo(f,caption=f"QRIS\nNominal wajib: Rp{data['expected_amount']:,}\nOrder: {data['order_id']}")
 except FileNotFoundError: pass
async def status(u,c):
 if not c.args: return await u.message.reply_text('Format: /paystatus ORD-...')
 d=await api('GET',f"/orders/{c.args[0]}"); await u.message.reply_text(f"Order {d['order_id']}\nStatus: {d['status']}\nNominal: Rp{d['expected_amount']:,}")
async def heartbeat(app):
 while True:
  try: await api('POST','/bot-heartbeat',{})
  except Exception: pass
  await asyncio.sleep(30)
async def post_init(app): app.create_task(heartbeat(app))
app=Application.builder().token(BOT_TOKEN).post_init(post_init).build(); app.add_handler(CommandHandler('start',start)); app.add_handler(CommandHandler('order',order)); app.add_handler(CommandHandler('paystatus',status)); app.run_polling()
