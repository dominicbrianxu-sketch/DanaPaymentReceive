# Payment Bridge Server

`/orders` membuat order dengan expected_amount = base_amount + unique_code.
`/payment-notify` hanya mengubah order menjadi PAID jika nominal DANA sama persis dengan expected_amount dan order masih PENDING.
`/receiver-heartbeat` dan `/bot-heartbeat` dipakai untuk status koneksi.

Jalankan API: `uvicorn app:app --host 0.0.0.0 --port 5005`
Jalankan bot: `python telegram_bot.py`

Untuk QRIS static, file `qris.png` hanya menjadi gambar pembayaran. Nominal wajib ditampilkan terpisah. Jika ingin nominal tertanam di payload QRIS, gunakan QRIS dinamis/provider yang mendukung amount.
