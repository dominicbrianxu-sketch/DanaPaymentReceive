package com.varino.danapaymentreceiver
import android.content.Context
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.util.concurrent.TimeUnit
object PaymentSender {
 private const val TAG="DanaReceiver"
 private val client=OkHttpClient.Builder().connectTimeout(8,TimeUnit.SECONDS).readTimeout(12,TimeUnit.SECONDS).writeTimeout(12,TimeUnit.SECONDS).build()
 private fun req(c:Context,path:String,body:JSONObject):Request?{ val base=Prefs.getEndpoint(c).trim().removeSuffix("/"); val token=Prefs.getToken(c).trim(); if(base.isBlank()||token.isBlank()) return null; val root=base.removeSuffix("/payment-notify"); return Request.Builder().url(root+path).addHeader("X-Tasker-Token",token).addHeader("Content-Type","application/json").post(body.toString().toRequestBody("application/json".toMediaType())).build() }
 fun send(c:Context,d:PaymentData){ val b=JSONObject().apply{put("nominal",d.nominal);put("nama_pengirim",d.namaPengirim);put("waktu",OffsetDateTime.now(ZoneOffset.ofHours(7)).toString());put("jenis_transaksi",d.jenisTransaksi);put("catatan",d.catatan);put("source",d.source)}; val r=req(c,"/payment-notify",b)?:return; Thread{try{client.newCall(r).execute().use{x->val s=x.body?.string().orEmpty();Log.i(TAG,"payment-notify HTTP ${x.code}: $s");Prefs.setLastServerStatus(c,x.isSuccessful,s)}}catch(e:Exception){Log.e(TAG,"payment send",e);Prefs.setLastServerStatus(c,false,e.message?:"connection error")}}.start() }
 fun heartbeat(c:Context){val b=JSONObject().apply{put("device",android.os.Build.MODEL);put("app_version","2.0");put("notification_access",DanaNotificationListener.isEnabled(c));put("source","DANA")};val r=req(c,"/receiver-heartbeat",b)?:return;Thread{try{client.newCall(r).execute().use{x->Prefs.setLastServerStatus(c,x.isSuccessful,x.body?.string().orEmpty())}}catch(e:Exception){Prefs.setLastServerStatus(c,false,e.message?:"connection error")}}.start()}
 fun sendTest(c:Context,cb:(Boolean,String)->Unit){val b=JSONObject().apply{put("device",android.os.Build.MODEL);put("app_version","2.0");put("notification_access",DanaNotificationListener.isEnabled(c));put("source","DANA")};val r=req(c,"/receiver-test",b);if(r==null){cb(false,"Endpoint/token belum diisi");return};Thread{try{client.newCall(r).execute().use{x->cb(x.isSuccessful,"Server HTTP ${x.code}: ${x.body?.string().orEmpty()}")}}catch(e:Exception){cb(false,"Gagal koneksi: ${e.message}")}}.start()}
}
