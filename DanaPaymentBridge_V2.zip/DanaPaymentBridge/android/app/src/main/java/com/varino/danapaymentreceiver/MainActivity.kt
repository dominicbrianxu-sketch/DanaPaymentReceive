package com.varino.danapaymentreceiver
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
class MainActivity:AppCompatActivity(){private lateinit var u:TextInputEditText;private lateinit var t:TextInputEditText;private lateinit var s:android.widget.TextView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);u=findViewById(R.id.urlInput);t=findViewById(R.id.tokenInput);s=findViewById(R.id.statusText);u.setText(Prefs.getEndpoint(this));t.setText(Prefs.getToken(this));findViewById<MaterialButton>(R.id.saveButton).setOnClickListener{val a=u.text?.toString()?.trim().orEmpty();val z=t.text?.toString()?.trim().orEmpty();if(a.isBlank()||z.isBlank()){Toast.makeText(this,"Endpoint dan token wajib diisi",Toast.LENGTH_SHORT).show();return@setOnClickListener};Prefs.save(this,a,z);startHB();update()};findViewById<MaterialButton>(R.id.permissionButton).setOnClickListener{startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))};findViewById<MaterialButton>(R.id.testButton).setOnClickListener{Prefs.save(this,u.text?.toString()?.trim().orEmpty(),t.text?.toString()?.trim().orEmpty());PaymentSender.sendTest(this){ok,m->runOnUiThread{s.text=if(ok)"🟢 SERVER CONNECTED\n$m" else "🔴 SERVER DISCONNECTED\n$m"}}};startHB();update()}
 override fun onResume(){super.onResume();update()};private fun startHB(){val i=Intent(this,ReceiverHeartbeatService::class.java);if(Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i)};private fun update(){s.text="DANA Notification: ${if(DanaNotificationListener.isEnabled(this))"🟢 CONNECTED" else "🔴 DISCONNECTED"}\nPayment Server: ${if(Prefs.serverOk(this))"🟢 CONNECTED" else "🔴 DISCONNECTED"}\n${Prefs.serverMsg(this)}"}}
