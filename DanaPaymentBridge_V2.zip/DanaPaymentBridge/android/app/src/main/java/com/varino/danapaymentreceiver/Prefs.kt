package com.varino.danapaymentreceiver
import android.content.Context
object Prefs {
 private const val NAME="receiver"; private const val ENDPOINT="endpoint"; private const val TOKEN="token"; private const val SERVER_OK="server_ok"; private const val SERVER_MSG="server_msg"
 fun save(c:Context,u:String,t:String)=c.getSharedPreferences(NAME,0).edit().putString(ENDPOINT,u).putString(TOKEN,t).apply()
 fun getEndpoint(c:Context)=c.getSharedPreferences(NAME,0).getString(ENDPOINT,"")? : ""
 fun getToken(c:Context)=c.getSharedPreferences(NAME,0).getString(TOKEN,"")? : ""
 fun setLastServerStatus(c:Context,ok:Boolean,msg:String)=c.getSharedPreferences(NAME,0).edit().putBoolean(SERVER_OK,ok).putString(SERVER_MSG,msg.take(300)).apply()
 fun serverOk(c:Context)=c.getSharedPreferences(NAME,0).getBoolean(SERVER_OK,false)
 fun serverMsg(c:Context)=c.getSharedPreferences(NAME,0).getString(SERVER_MSG,"")? : ""
}
