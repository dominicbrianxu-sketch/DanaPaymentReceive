package com.varino.danapaymentreceiver
import android.app.*
import android.content.Intent
import android.os.*
class ReceiverHeartbeatService:Service(){private val h=Handler(Looper.getMainLooper());private val r=object:Runnable{override fun run(){PaymentSender.heartbeat(applicationContext);h.postDelayed(this,30000)}}
 override fun onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26){val n=getSystemService(NotificationManager::class.java);n.createNotificationChannel(NotificationChannel("receiver","Payment Receiver",NotificationManager.IMPORTANCE_LOW))};val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,"receiver") else Notification.Builder(this);startForeground(1001,n.setContentTitle("DANA Payment Receiver").setContentText("Payment bridge aktif").setSmallIcon(android.R.drawable.stat_notify_sync_noanim).build());h.post(r)}
 override fun onDestroy(){h.removeCallbacks(r);super.onDestroy()};override fun onBind(i:Intent?):IBinder?=null}
