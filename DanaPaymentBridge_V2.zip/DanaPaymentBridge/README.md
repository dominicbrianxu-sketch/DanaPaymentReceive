# DANA Payment Receiver V2 + Telegram Payment Bridge

- android/: APK Notification Listener DANA + heartbeat.
- server/: payment matching server + Telegram bot adapter.
- codemagic.yaml: build APK.

Flow: Telegram order -> server creates expected amount -> bot shows QRIS + exact amount -> DANA notification -> APK sends payment -> server exact-match -> PAID.

Do not commit tokens. Use HTTPS in production.
