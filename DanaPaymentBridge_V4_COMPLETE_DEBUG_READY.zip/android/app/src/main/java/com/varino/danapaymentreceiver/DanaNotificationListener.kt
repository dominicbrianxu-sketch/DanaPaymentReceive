package com.varino.danapaymentreceiver

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.concurrent.ConcurrentHashMap

class DanaNotificationListener : NotificationListenerService() {

    companion object {
        private const val TAG = "DanaReceiver"
        private const val DANA_PACKAGE = "id.dana"
        private val seen = ConcurrentHashMap.newKeySet<String>()

        fun isEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            return enabled.contains(context.packageName)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != DANA_PACKAGE) return
        DebugLogger.log("NOTIF", "Notifikasi DANA masuk; key=${sbn.key}")

        val n = sbn.notification
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val combined = listOfNotNull(text, bigText).joinToString("\n")

        val fingerprint = "${sbn.key}|${title ?: ""}|$combined"
        if (!seen.add(fingerprint)) return

        // Batasi cache agar tidak tumbuh tanpa batas.
        if (seen.size > 500) {
            val first = seen.firstOrNull()
            if (first != null) seen.remove(first)
        }

        Log.i(TAG, "Notifikasi DANA: title=$title text=$combined")
        DebugLogger.log("NOTIF", "Title=${title.orEmpty()} | Text=${combined.take(240)}")

        val data = PaymentParser.parse(title, combined)
        if (data != null) {
            DebugLogger.log("PARSER", "Nominal terdeteksi: Rp${data.nominal}; sumber=${data.source}; jenis=${data.jenisTransaksi}")
            PaymentSender.send(applicationContext, data)
        } else {
            DebugLogger.log("PARSER", "Tidak dikirim: notifikasi tidak memenuhi pola pembayaran atau nominal tidak terbaca")
        }
    }
}
