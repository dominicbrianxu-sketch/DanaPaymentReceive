package com.varino.danapaymentreceiver

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** On-device diagnostics screen for notification parsing and server requests. */
class LogActivity : AppCompatActivity() {
    private lateinit var logTextView: TextView
    private lateinit var scrollView: ScrollView
    private val updateListener: () -> Unit = {
        runOnUiThread { updateLogs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Log Debug APK"

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 18, 18))
        }

        val btnClear = Button(this).apply {
            text = "Hapus Log (Clear)"
            setOnClickListener { DebugLogger.clear() }
        }

        scrollView = ScrollView(this)
        logTextView = TextView(this).apply {
            setTextColor(Color.rgb(0, 255, 120))
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        scrollView.addView(logTextView)
        layout.addView(btnClear, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        layout.addView(scrollView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))
        setContentView(layout)
        DebugLogger.setListener(updateListener)
        updateLogs()
    }

    private fun updateLogs() {
        if (!::logTextView.isInitialized) return
        logTextView.text = DebugLogger.getLogs().ifBlank { "Belum ada log." }
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        DebugLogger.setListener(null)
        super.onDestroy()
    }
}
