package com.varino.danapaymentreceiver

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log debug ring-buffer for on-device diagnostics.
 * Keeps a bounded number of entries so the log screen does not grow forever.
 */
object DebugLogger {
    private const val MAX_LOGS = 300
    private val lock = Any()
    private val logs = ArrayDeque<String>()
    private val formatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    @Volatile private var listener: (() -> Unit)? = null

    fun log(tag: String, message: String) {
        val timestamp = synchronized(formatter) { formatter.format(Date()) }
        val entry = "[$timestamp] [$tag] $message"
        synchronized(lock) {
            logs.addLast(entry)
            while (logs.size > MAX_LOGS) logs.removeFirst()
        }
        Log.d("DANA_RECEIVER", entry)
        listener?.invoke()
    }

    fun getLogs(): String = synchronized(lock) { logs.joinToString("\n") }

    fun clear() {
        synchronized(lock) { logs.clear() }
        listener?.invoke()
    }

    fun setListener(callback: (() -> Unit)?) {
        listener = callback
    }
}
