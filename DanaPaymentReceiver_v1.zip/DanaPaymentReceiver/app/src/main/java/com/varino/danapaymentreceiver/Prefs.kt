package com.varino.danapaymentreceiver

import android.content.Context

object Prefs {
    private const val NAME = "receiver"
    private const val ENDPOINT = "endpoint"
    private const val TOKEN = "token"

    fun save(context: Context, endpoint: String, token: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(ENDPOINT, endpoint)
            .putString(TOKEN, token)
            .apply()
    }

    fun getEndpoint(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(ENDPOINT, "") ?: ""

    fun getToken(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(TOKEN, "") ?: ""
}
