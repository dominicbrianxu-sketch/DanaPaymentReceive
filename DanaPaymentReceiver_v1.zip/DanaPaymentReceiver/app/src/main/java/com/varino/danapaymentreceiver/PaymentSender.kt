package com.varino.danapaymentreceiver

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object PaymentSender {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    fun send(context: Context, data: PaymentData) {
        val endpoint = Prefs.getEndpoint(context)
        val token = Prefs.getToken(context)
        if (endpoint.isBlank() || token.isBlank()) return

        val body = JSONObject().apply {
            put("nominal", data.nominal.toString())
            put("nama_pengirim", data.namaPengirim)
            put("waktu", java.time.LocalDateTime.now().toString().replace("T", " "))
            put("jenis_transaksi", data.jenisTransaksi)
            put("catatan", data.catatan)
            put("source", data.source)
        }.toString()

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("X-Tasker-Token", token)
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        Thread {
            try {
                client.newCall(request).execute().use { response ->
                    android.util.Log.i("DanaReceiver", "payment-notify HTTP ${response.code}")
                }
            } catch (e: Exception) {
                android.util.Log.e("DanaReceiver", "Gagal kirim payment", e)
            }
        }.start()
    }

    fun sendTest(context: Context, callback: (Boolean, String) -> Unit) {
        val endpoint = Prefs.getEndpoint(context)
        val token = Prefs.getToken(context)
        val body = JSONObject().apply {
            put("nominal", "1")
            put("nama_pengirim", "TEST_RECEIVER")
            put("waktu", java.time.LocalDateTime.now().toString().replace("T", " "))
            put("jenis_transaksi", "TEST")
            put("catatan", "Test koneksi DANA Payment Receiver")
            put("source", "DANA")
        }.toString()

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("X-Tasker-Token", token)
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        Thread {
            try {
                client.newCall(request).execute().use { response ->
                    callback(response.isSuccessful, "HTTP ${response.code}")
                }
            } catch (e: Exception) {
                callback(false, "Gagal koneksi: ${e.message}")
            }
        }.start()
    }
}
