package com.varino.danapaymentreceiver

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: TextInputEditText
    private lateinit var tokenInput: TextInputEditText
    private lateinit var statusText: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        tokenInput = findViewById(R.id.tokenInput)
        statusText = findViewById(R.id.statusText)

        urlInput.setText(Prefs.getEndpoint(this))
        tokenInput.setText(Prefs.getToken(this))

        findViewById<MaterialButton>(R.id.saveButton).setOnClickListener {
            val url = urlInput.text?.toString()?.trim().orEmpty()
            val token = tokenInput.text?.toString()?.trim().orEmpty()
            if (url.isBlank() || token.isBlank()) {
                Toast.makeText(this, "Endpoint dan token wajib diisi.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.save(this, url, token)
            Toast.makeText(this, "Konfigurasi disimpan.", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.permissionButton).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        findViewById<MaterialButton>(R.id.testButton).setOnClickListener {
            val url = urlInput.text?.toString()?.trim().orEmpty()
            val token = tokenInput.text?.toString()?.trim().orEmpty()
            if (url.isBlank() || token.isBlank()) {
                Toast.makeText(this, "Isi endpoint dan token dulu.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.save(this, url, token)
            PaymentSender.sendTest(this) { ok, message ->
                runOnUiThread {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    statusText.text = message
                }
            }
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        statusText.text = if (DanaNotificationListener.isEnabled(this)) {
            "Status: Notification Access AKTIF"
        } else {
            "Status: Notification Access BELUM AKTIF"
        }
    }
}
