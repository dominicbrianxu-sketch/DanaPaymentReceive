# Payment Bridge Server

`/orders` membuat order dengan `expected_amount = base_amount + unique_code`.
`/payment-notify` hanya mengubah order menjadi `PAID` jika nominal DANA sama
persis dengan `expected_amount` dan order masih `PENDING`. Begitu cocok, server
langsung mengirim pesan Telegram ke buyer (order bisa lanjut diproses) —
tidak perlu polling `/paystatus` lagi.

`/receiver-heartbeat` dan `/bot-heartbeat` dipakai untuk status koneksi.
Kalau `ADMIN_CHAT_ID` diisi, server otomatis kirim notif ke chat itu setiap kali
APK DANA Receiver atau Bot Telegram berubah status TERHUBUNG/TERPUTUS.

## Menjalankan

```bash
pip install -r requirements.txt
cp .env.example .env   # isi PAYMENT_TOKEN, TELEGRAM_BOT_TOKEN, ADMIN_CHAT_ID
export $(cat .env | xargs)

uvicorn app:app --host 0.0.0.0 --port 5005   # jalankan server
python telegram_bot.py                        # jalankan bot (proses terpisah)
```

## Catatan QRIS

Untuk QRIS static, file `qris.png` hanya menjadi gambar pembayaran. Nominal
wajib ditampilkan terpisah di caption/teks (bukan tertanam di QR-nya). Jika
ingin nominal benar-benar tertanam di payload QRIS (QRIS dinamis), butuh
provider/PJSP yang mendukung generate QRIS dinamis per transaksi — DANA
personal biasanya hanya punya QRIS statis, jadi pendekatan "kode unik di
belakang nominal" ini adalah cara paling umum dipakai untuk kasus ini.
