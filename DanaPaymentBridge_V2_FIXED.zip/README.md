# DANA Payment Receiver V2 + Telegram Payment Bridge

- `android/`: APK Notification Listener DANA + heartbeat.
- `server/`: payment matching server + Telegram bot adapter.
- `codemagic.yaml`: build APK.

Flow:
Telegram `/order` -> server buat expected_amount (base + kode unik 3 digit) ->
bot kirim QRIS + nominal wajib -> notifikasi DANA masuk di HP -> APK kirim ke
server -> server cocokkan nominal PERSIS -> status jadi PAID -> **server langsung
kirim notif ke buyer di Telegram (otomatis, tanpa perlu cek manual)**.

## Fitur notifikasi koneksi (baru)
Server memantau heartbeat APK (`dana_receiver`) dan bot (`telegram_bot`) tiap 20
detik. Kalau salah satunya berubah status TERHUBUNG <-> TERPUTUS, dan
`ADMIN_CHAT_ID` diisi di `.env`, server otomatis kirim pesan ke chat itu. Lihat
`server/.env.example` untuk cara mendapatkan `ADMIN_CHAT_ID`.

Do not commit tokens. Use HTTPS in production.
