# DANA Payment Receiver

APK Android untuk membaca notifikasi pembayaran dari aplikasi DANA lalu mengirim data pembayaran ke `payment_listener.py`.

## Arsitektur

DANA notification -> NotificationListenerService -> parser nominal -> HTTP POST -> `/payment-notify` -> payment_listener.py -> wallet_exchange.py

## Konfigurasi

Di aplikasi:
1. Isi endpoint, contoh:
   `http://SERVER_ANDA:5005/payment-notify`
2. Isi token yang sama dengan token di `payment_listener.py`.
3. Simpan.
4. Aktifkan Notification Access.
5. Gunakan Test Koneksi.

## Catatan penting

- Tidak memakai Tasker.
- Tidak memakai MacroDroid.
- APK hanya membaca notifikasi dari package DANA `id.dana`.
- Parser bersifat konservatif dan tidak mengirim notifikasi yang tidak terlihat seperti pembayaran.
- Untuk produksi, sebaiknya endpoint memakai HTTPS/reverse proxy.
- Jangan memasukkan token ke repository publik.
- `payment_listener.py` saat ini menggunakan header `X-Tasker-Token`; APK sengaja memakai header yang sama agar kompatibel tanpa perubahan server.
