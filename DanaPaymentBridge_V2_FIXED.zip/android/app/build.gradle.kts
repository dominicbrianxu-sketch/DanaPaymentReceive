plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.varino.danapaymentreceiver"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.varino.danapaymentreceiver"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Tanpa signingConfig, output APK diberi nama "app-release-unsigned.apk"
            // (tidak bisa langsung diinstall). Pakai debug keystore bawaan supaya
            // hasilnya "app-release.apk" yang sudah ditandatangani & siap diinstall.
            // Untuk rilis ke publik/Play Store, ganti dengan keystore rilis sendiri.
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
