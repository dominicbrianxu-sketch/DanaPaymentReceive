package com.varino.danapaymentreceiver

import java.text.Normalizer
import java.util.Locale

data class PaymentData(
    val nominal: Long,
    val namaPengirim: String = "",
    val catatan: String = "",
    val jenisTransaksi: String = "QRIS",
    val source: String = "DANA"
)

object PaymentParser {

    /*
     * Parser sengaja konservatif:
     * - hanya mencoba nominal jika notifikasi DANA terlihat seperti pembayaran/uang masuk;
     * - menghindari angka kecil seperti OTP, waktu, atau nomor referensi;
     * - nominal dikirim sebagai integer Rupiah.
     */
    private val moneyRegex = Regex(
        """(?i)(?:rp\s*)?([0-9]{1,3}(?:[.\s][0-9]{3})+|[0-9]{4,})"""
    )

    private val positiveWords = listOf(
        "uang masuk", "menerima", "diterima", "pembayaran", "qr", "qris",
        "transfer masuk", "dana masuk", "berhasil menerima", "received"
    )

    fun parse(title: String?, text: String?): PaymentData? {
        val raw = listOfNotNull(title, text).joinToString("\n").trim()
        if (raw.isBlank()) return null

        val normalized = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFKC)
        val looksLikePayment = positiveWords.any { normalized.contains(it) }

        if (!looksLikePayment) return null

        val candidates = moneyRegex.findAll(raw).mapNotNull { m ->
            val digits = m.groupValues[1].replace(".", "").replace(" ", "")
            digits.toLongOrNull()
        }.filter { it >= 1000L && it <= 1_000_000_000L }.toList()

        if (candidates.isEmpty()) return null

        // Bias ke angka yang memiliki "Rp" di dekatnya, jika ada.
        val rpMatch = Regex("""(?i)rp\s*([0-9][0-9.\s]*)""").find(raw)
        val nominal = rpMatch?.groupValues?.getOrNull(1)
            ?.replace(".", "")?.replace(" ", "")?.toLongOrNull()
            ?: candidates.maxOrNull()
            ?: return null

        val sender = extractSender(raw)
        return PaymentData(
            nominal = nominal,
            namaPengirim = sender,
            catatan = raw.take(500)
        )
    }

    private fun extractSender(raw: String): String {
        val patterns = listOf(
            Regex("""(?im)(?:dari|from|pengirim|sender)\s*[:\-]?\s*([^\n]{2,80})"""),
            Regex("""(?im)(?:oleh|by)\s*[:\-]?\s*([^\n]{2,80})""")
        )
        for (p in patterns) {
            val value = p.find(raw)?.groupValues?.getOrNull(1)?.trim()
            if (!value.isNullOrBlank()) return value
        }
        return ""
    }
}
