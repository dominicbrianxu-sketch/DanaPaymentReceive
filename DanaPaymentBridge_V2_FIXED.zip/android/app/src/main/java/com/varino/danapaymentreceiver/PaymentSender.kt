package com.varino.danapaymentreceiver

import android.content.Context
import android.os.Build
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object PaymentSender {
    private const val TAG = "DanaReceiver"

    // Mencegah beberapa retry berjalan bersamaan (mis. dipicu network-callback
    // dan heartbeat tick pada saat yang hampir sama).
    private val retryInProgress = AtomicBoolean(false)

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .build()

    private fun req(c: Context, path: String, bodyJson: String): Request? {
        val base = Prefs.getEndpoint(c).trim().removeSuffix("/")
        val token = Prefs.getToken(c).trim()
        if (base.isBlank() || token.isBlank()) return null

        val root = base.removeSuffix("/payment-notify")
        return Request.Builder()
            .url(root + path)
            .addHeader("X-Tasker-Token", token)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody("application/json".toMediaType()))
            .build()
    }

    /** Kirim satu payload payment-notify secara SINKRON (dipanggil dari thread background).
     * Return true kalau server menjawab sukses (HTTP 2xx). */
    private fun sendPaymentSync(c: Context, bodyJson: String): Boolean {
        val request = req(c, "/payment-notify", bodyJson) ?: return false
        return try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                Log.i(TAG, "payment-notify HTTP ${response.code}: $responseBody")
                Prefs.setLastServerStatus(c, response.isSuccessful, responseBody)
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e(TAG, "payment send gagal, akan diantrekan untuk dicoba lagi", e)
            Prefs.setLastServerStatus(c, false, e.message ?: "connection error")
            false
        }
    }

    /** Notifikasi pembayaran DANA baru terdeteksi. Kalau internet sedang mati / server
     * tidak bisa dihubungi, payload TIDAK HILANG — otomatis diantrekan dan akan dicoba
     * kirim ulang begitu koneksi pulih (lihat retryPendingPayments & ReceiverHeartbeatService). */
    fun send(c: Context, d: PaymentData) {
        val body = JSONObject().apply {
            put("nominal", d.nominal)
            put("nama_pengirim", d.namaPengirim)
            put("waktu", OffsetDateTime.now(ZoneOffset.ofHours(7)).toString())
            put("jenis_transaksi", d.jenisTransaksi)
            put("catatan", d.catatan)
            put("source", d.source)
        }
        val bodyJson = body.toString()

        Thread {
            val ok = sendPaymentSync(c, bodyJson)
            if (!ok) {
                Prefs.addPendingPayment(c, bodyJson)
            }
        }.start()
    }

    /** Coba kirim ulang semua pembayaran yang tertunda di antrian (karena sebelumnya
     * gagal saat internet/ server bermasalah). Dipanggil berkala (heartbeat tick) DAN
     * langsung begitu koneksi internet terdeteksi kembali online. */
    fun retryPendingPayments(c: Context) {
        if (!retryInProgress.compareAndSet(false, true)) return
        Thread {
            try {
                val pending = Prefs.getPendingPayments(c)
                if (pending.isEmpty()) return@Thread
                Log.i(TAG, "Mencoba kirim ulang ${pending.size} pembayaran yang tertunda")
                for (payload in pending) {
                    val ok = sendPaymentSync(c, payload)
                    if (ok) {
                        Prefs.removePendingPayment(c, payload)
                    } else {
                        // Kalau satu gagal (mis. internet putus lagi di tengah proses),
                        // hentikan batch ini; sisanya tetap di antrian untuk dicoba lagi nanti.
                        break
                    }
                }
            } finally {
                retryInProgress.set(false)
            }
        }.start()
    }

    fun heartbeat(c: Context) {
        val body = JSONObject().apply {
            put("device", Build.MODEL)
            put("app_version", "2.1.0")
            put("notification_access", DanaNotificationListener.isEnabled(c))
            put("source", "DANA")
        }
        val request = req(c, "/receiver-heartbeat", body.toString())

        Thread {
            // Setiap heartbeat juga jadi kesempatan mencoba kirim ulang antrian pembayaran
            // yang sempat gagal -- jadi tidak perlu menunggu event khusus.
            retryPendingPayments(c)

            if (request == null) return@Thread
            try {
                client.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string().orEmpty()
                    Prefs.setLastServerStatus(c, response.isSuccessful, responseBody)
                }
            } catch (e: Exception) {
                Prefs.setLastServerStatus(c, false, e.message ?: "connection error")
            }
        }.start()
    }

    fun sendTest(c: Context, callback: (Boolean, String) -> Unit) {
        val body = JSONObject().apply {
            put("device", Build.MODEL)
            put("app_version", "2.1.0")
            put("notification_access", DanaNotificationListener.isEnabled(c))
            put("source", "DANA")
        }
        val request = req(c, "/receiver-test", body.toString())
        if (request == null) {
            callback(false, "Endpoint/token belum diisi")
            return
        }

        Thread {
            try {
                client.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string().orEmpty()
                    Prefs.setLastServerStatus(c, response.isSuccessful, responseBody)
                    callback(response.isSuccessful, "Server HTTP ${response.code}: $responseBody")
                }
            } catch (e: Exception) {
                callback(false, "Gagal koneksi: ${e.message}")
            }
        }.start()
    }
}
