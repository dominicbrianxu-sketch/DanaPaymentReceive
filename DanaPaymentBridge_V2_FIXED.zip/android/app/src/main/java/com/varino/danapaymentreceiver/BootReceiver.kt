package com.varino.danapaymentreceiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Menghidupkan lagi ReceiverHeartbeatService otomatis setelah HP restart, atau setelah
 * aplikasi diupdate. Tanpa ini, kalau HP dimatikan-nyalakan (mis. mati listrik/reboot),
 * bridge pembayaran akan diam dan tidak akan reconnect sampai user buka app manual.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            // Hanya nyalakan kalau endpoint & token sudah pernah dikonfigurasi.
            if (Prefs.getEndpoint(context).isBlank() || Prefs.getToken(context).isBlank()) return

            val serviceIntent = Intent(context, ReceiverHeartbeatService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
