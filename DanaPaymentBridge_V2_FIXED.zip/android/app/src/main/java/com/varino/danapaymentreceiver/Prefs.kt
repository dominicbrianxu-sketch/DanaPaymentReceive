package com.varino.danapaymentreceiver

import android.content.Context
import org.json.JSONArray

object Prefs {
    private const val NAME = "receiver"
    private const val ENDPOINT = "endpoint"
    private const val TOKEN = "token"
    private const val SERVER_OK = "server_ok"
    private const val SERVER_MSG = "server_msg"
    private const val PENDING_PAYMENTS = "pending_payments"
    private const val MAX_PENDING = 200 // batas antrian, mencegah storage membengkak tanpa batas

    fun save(c: Context, url: String, token: String) =
        c.getSharedPreferences(NAME, 0).edit()
            .putString(ENDPOINT, url)
            .putString(TOKEN, token)
            .apply()

    fun getEndpoint(c: Context): String =
        c.getSharedPreferences(NAME, 0).getString(ENDPOINT, "").orEmpty()

    fun getToken(c: Context): String =
        c.getSharedPreferences(NAME, 0).getString(TOKEN, "").orEmpty()

    fun setLastServerStatus(c: Context, ok: Boolean, msg: String) =
        c.getSharedPreferences(NAME, 0).edit()
            .putBoolean(SERVER_OK, ok)
            .putString(SERVER_MSG, msg.take(300))
            .apply()

    fun serverOk(c: Context): Boolean =
        c.getSharedPreferences(NAME, 0).getBoolean(SERVER_OK, false)

    fun serverMsg(c: Context): String =
        c.getSharedPreferences(NAME, 0).getString(SERVER_MSG, "").orEmpty()

    // ---------- Antrian pembayaran yang gagal terkirim (mis. saat internet mati) ----------
    // Supaya notifikasi pembayaran DANA TIDAK HILANG walau internet sedang putus:
    // disimpan di sini dulu, lalu dicoba kirim ulang otomatis saat internet nyala lagi.

    @Synchronized
    fun getPendingPayments(c: Context): List<String> {
        val raw = c.getSharedPreferences(NAME, 0).getString(PENDING_PAYMENTS, "[]")
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun addPendingPayment(c: Context, payloadJson: String) {
        val current = getPendingPayments(c).toMutableList()
        current.add(payloadJson)
        // Kalau antrian kepenuhan, buang yang paling lama supaya storage tidak membengkak
        // (kasus ekstrem: internet mati sangat lama dengan banyak pembayaran masuk).
        while (current.size > MAX_PENDING) current.removeAt(0)
        savePendingPayments(c, current)
    }

    @Synchronized
    fun removePendingPayment(c: Context, payloadJson: String) {
        val current = getPendingPayments(c).toMutableList()
        current.remove(payloadJson)
        savePendingPayments(c, current)
    }

    private fun savePendingPayments(c: Context, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        c.getSharedPreferences(NAME, 0).edit().putString(PENDING_PAYMENTS, arr.toString()).apply()
    }
}
