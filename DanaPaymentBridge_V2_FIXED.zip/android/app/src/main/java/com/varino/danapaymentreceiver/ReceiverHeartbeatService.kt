package com.varino.danapaymentreceiver

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.*
import android.util.Log

/**
 * Service foreground yang menjaga koneksi tetap hidup:
 * - Kirim heartbeat tiap 30 detik (dan coba kirim ulang antrian pembayaran tertunda).
 * - Memantau perubahan konektivitas: begitu internet nyala lagi setelah padam,
 *   langsung reconnect (tanpa menunggu siklus 30 detik berikutnya).
 * - START_STICKY supaya Android otomatis menghidupkan lagi service ini kalau
 *   di-kill oleh sistem (low memory dsb).
 * - onTaskRemoved menjadwalkan restart via AlarmManager sebagai jaring pengaman
 *   tambahan untuk OEM yang agresif mematikan background service (Xiaomi/Oppo/Vivo dll).
 */
class ReceiverHeartbeatService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val heartbeatIntervalMs = 30_000L

    private val heartbeatRunnable = object : Runnable {
        override fun run() {
            PaymentSender.heartbeat(applicationContext)
            handler.postDelayed(this, heartbeatIntervalMs)
        }
    }

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("receiver", "Payment Receiver", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notif = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "receiver") else Notification.Builder(this)
        startForeground(
            1001,
            notif.setContentTitle("DANA Payment Receiver")
                .setContentText("Payment bridge aktif - memantau koneksi")
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .build()
        )

        registerNetworkCallback()
        handler.post(heartbeatRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Kalau proses di-kill sistem (bukan force-stop manual oleh user), Android akan
        // otomatis memanggil ulang service ini (dengan intent = null) -> onCreate jalan lagi.
        return START_STICKY
    }

    private fun registerNetworkCallback() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                Log.i(TAG, "Internet tersedia -> reconnect & kirim ulang antrian pembayaran")
                PaymentSender.heartbeat(applicationContext)
            }

            override fun onLost(network: Network) {
                Log.w(TAG, "Internet terputus di perangkat")
                Prefs.setLastServerStatus(applicationContext, false, "Internet terputus di perangkat")
            }
        }
        networkCallback = callback
        try {
            connectivityManager?.registerNetworkCallback(request, callback)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal mendaftarkan network callback", e)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        scheduleRestart()
        super.onTaskRemoved(rootIntent)
    }

    private fun scheduleRestart() {
        try {
            val restartIntent = Intent(applicationContext, ReceiverHeartbeatService::class.java)
            val pendingIntent = if (Build.VERSION.SDK_INT >= 26) {
                PendingIntent.getForegroundService(
                    applicationContext, 1, restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                PendingIntent.getService(
                    applicationContext, 1, restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
            }
            // Non-exact: cukup untuk kasus restart service, dan tidak butuh izin
            // SCHEDULE_EXACT_ALARM yang lebih dibatasi Google Play.
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 2000,
                pendingIntent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menjadwalkan restart service", e)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(heartbeatRunnable)
        try {
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
        } catch (e: Exception) {
            // sudah tidak terdaftar / connectivityManager null, aman diabaikan
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "DanaReceiver"
    }
}
